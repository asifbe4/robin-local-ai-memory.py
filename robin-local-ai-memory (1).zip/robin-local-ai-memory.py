#!/usr/bin/env python3
"""Local ChatGPT -> Llama/Ollama memory builder.

Reads a ChatGPT conversations.json export and creates a local Markdown memory
archive plus a curated MASTER_MEMORY.md using an Ollama/Llama model.
"""
import argparse, json, re, sys, urllib.request
from collections import defaultdict
from datetime import datetime
from pathlib import Path

SYSTEM = '''You are a careful personal-memory curator. Extract only information explicitly supported by the supplied conversation. Do not invent facts or infer sensitive personal attributes. Prefer durable preferences, projects, technical configuration, ideas, and decisions. Return concise Markdown bullets.'''
TOPICS = {
 "PROFILE": ["name", "assistant", "chey", "cheyenne", "preference"],
 "AI_HARDWARE": ["gpu", "rtx", "quadro", "ram", "vram", "ollama", "open webui", "comfyui", "linux", "arch linux", "hardware", "cpu"],
 "CREATIVE_PROJECTS": ["averixa", "chromo", "neocortex", "eidolon", "ai art", "image", "comfyui", "krita", "gimp"],
 "WRITING_STYLE": ["tweet", "x/twitter", "cinematic", "vocabulary", "poetic", "cryptic", "natural", "human sounding"],
 "SCIENCE_IDEAS": ["physics", "quantum", "relativity", "light cone", "delta", "einstein", "consciousness"],
 "WORKFLOWS": ["workflow", "script", "memory", "agent", "rag", "knowledge base", "python", "local ai"]}

def date(v):
    try: return datetime.fromtimestamp(v).strftime('%Y-%m-%d %H:%M') if isinstance(v,(int,float)) else str(v or '')
    except: return ''

def text(content):
    if not isinstance(content,dict): return ''
    out=[]
    for p in content.get('parts',[]):
        if isinstance(p,str): out.append(p)
        elif isinstance(p,dict):
            if isinstance(p.get('text'),str): out.append(p['text'])
            elif isinstance(p.get('content'),str): out.append(p['content'])
    return '\n'.join(x for x in out if x).strip()

def rows(c):
    r=[]
    for n in (c.get('mapping') or {}).values():
        m=(n or {}).get('message')
        if not m: continue
        role=((m.get('author') or {}).get('role') or '').lower()
        if role not in {'user','assistant','system'}: continue
        t=text(m.get('content'))
        if t: r.append((date(m.get('create_time')),role,t))
    return sorted(r,key=lambda x:x[0])

def ollama(prompt,model,url):
    body=json.dumps({'model':model,'prompt':prompt,'system':SYSTEM,'stream':False,'options':{'temperature':0.1}}).encode()
    req=urllib.request.Request(url.rstrip('/')+'/api/generate',data=body,headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=300) as r: return json.loads(r.read())['response'].strip()

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',required=True,help='ChatGPT conversations.json')
    ap.add_argument('--output',default='robin_local_memory')
    ap.add_argument('--model',default='llama3.2:3b',help='Any Ollama Llama-family model')
    ap.add_argument('--ollama',default='http://127.0.0.1:11434')
    ap.add_argument('--no-llama',action='store_true',help='Build archive without local summarization')
    a=ap.parse_args(); inp=Path(a.input).expanduser(); out=Path(a.output).expanduser(); out.mkdir(parents=True,exist_ok=True)
    data=json.loads(inp.read_text(encoding='utf-8')); convs=data if isinstance(data,list) else data.get('conversations',[])
    archive=out/'CONVERSATION_ARCHIVE.md'
    chunks=[]; current=[]; chars=0; count=0
    with archive.open('w',encoding='utf-8') as f:
        f.write('# Robin — Complete Conversation Archive\n\n')
        for c in sorted(convs,key=lambda x:x.get('create_time') or 0):
            rs=rows(c)
            if not rs: continue
            count+=1; title=c.get('title') or 'Untitled conversation'; block=[f'CONVERSATION: {title}']
            f.write(f'## {title}\n\n')
            if c.get('create_time'): f.write(f"**Started:** {date(c['create_time'])}\n\n")
            for when,role,t in rs:
                f.write(f'### {role.capitalize()} ({when})\n\n{t}\n\n'); block.append(f'{role.upper()} ({when}): {t}')
            f.write('---\n\n')
            b='\n'.join(block)
            if chars+len(b)>12000 and current: chunks.append('\n\n'.join(current)); current=[]; chars=0
            current.append(b); chars+=len(b)
    if current: chunks.append('\n\n'.join(current))
    memories=defaultdict(list)
    for i,ch in enumerate(chunks,1):
        if a.no_llama:
            low=ch.lower(); topics=[k for k,ws in TOPICS.items() if any(w in low for w in ws)] or ['GENERAL']
            result='\n'.join([x[:3500] for x in [ch]])
        else:
            prompt=f'''Extract durable personal memory from this archive chunk. Use headings PROFILE, AI_HARDWARE, CREATIVE_PROJECTS, WRITING_STYLE, SCIENCE_IDEAS, WORKFLOWS, OTHER. Keep only explicit, useful, durable facts/preferences/projects/decisions. Ignore greetings and temporary chatter. Preserve technical values exactly.\n\nARCHIVE CHUNK {i}:\n{ch}'''
            try: result=ollama(prompt,a.model,a.ollama)
            except Exception as e:
                print(f'Warning: Ollama failed on chunk {i}: {e}',file=sys.stderr); continue
            topics=['OTHER'];
            for line in result.splitlines():
                m=re.match(r'^#+\s*(PROFILE|AI_HARDWARE|CREATIVE_PROJECTS|WRITING_STYLE|SCIENCE_IDEAS|WORKFLOWS|OTHER)\s*$',line,re.I)
                if m: topics=[m.group(1).upper()]; continue
                if line.strip().startswith(('-','*')):
                    for t in topics: memories[t].append(line.strip())
    for topic,items in memories.items():
        seen=set(); uniq=[]
        for x in items:
            k=re.sub(r'\s+',' ',x.lower()).strip()
            if k not in seen: seen.add(k); uniq.append(x)
        (out/f'{topic}.md').write_text('# '+topic.replace('_',' ').title()+'\n\n'+'\n'.join(uniq)+'\n',encoding='utf-8')
    master=['# Robin — Persistent Local AI Memory','', '> Curated from exported ChatGPT conversations. Generated locally.','', '## Memory Rules','', '- Treat this as reference, not absolute truth.','- Prefer recent explicit statements when memories conflict.','- Never invent missing information.','- Keep sensitive information out unless deliberately added by the owner.','']
    for topic in sorted(memories):
        master += [f'## {topic.replace("_"," ").title()}',''] + memories[topic] + ['']
    (out/'MASTER_MEMORY.md').write_text('\n'.join(master),encoding='utf-8')
    (out/'INDEX.md').write_text(f'''# Local AI Memory Index\n\n- Conversations processed: **{count}**\n- Memory model: **{"none" if a.no_llama else a.model}**\n- Generated locally: **yes**\n\n## Files\n\n- `MASTER_MEMORY.md` — curated persistent memory\n- `CONVERSATION_ARCHIVE.md` — complete extracted archive\n- Topic `.md` files — focused memory for retrieval\n\n## Ollama\n\nRun `ollama serve`, pull a Llama model, then rerun this builder.\n\n## Open WebUI\n\nImport this directory as a Knowledge Base. Keep the complete archive for retrieval and use `MASTER_MEMORY.md` as the compact persistent context.\n''',encoding='utf-8')
    print(f'Done: {out.resolve()}')

if __name__=='__main__': main()
